<?php


class Brizy_Admin_Migrations_UpgradeRequiredException  extends  Exception {

}