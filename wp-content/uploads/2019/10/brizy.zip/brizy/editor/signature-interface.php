<?php

interface Brizy_Editor_SignatureInterface {

	public function checkSignature();
}