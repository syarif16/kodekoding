<?php

class Brizy_Editor_Exceptions_Exception extends Exception {
	protected $code = 500;
	protected $message = 'Internal server error';
}