<?php

class Brizy_Editor_Constants {
	const BRIZY = 'brizy';
	const EDIT_KEY = 'brizy-edit';
	const EDIT_KEY_IFRAME = 'brizy-edit-iframe';
	const USES_BRIZY = 'brizy-use-brizy';
	const CONTENT_META_KEY = 'brizy-content';
}