<?php defined( 'ABSPATH' ) or die();

get_header();

do_action( 'brizy_template_content' );

get_footer();
